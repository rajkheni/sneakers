<script type="text/javascript" src="js/jquery.min.js" ></script>
<script type="text/javascript" src="js/lozad.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.js" ></script>
<script type="text/javascript" src="js/jquery.fancybox.pack.js" ></script>
<script type="text/javascript" src="js/custom.js"></script>